# HREmployeeAttrition
Python Machine Learning project on HR attrition solution. In this project we try to help HRs identify employees who are likely to leave the company.
